from __future__ import annotations

import logging
import os
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, render_template, request

from config import Config


APP_NAME = "Eagle Smart Scanner"
APP_VERSION = "2.0.0"
BASE_DIR = Path(__file__).resolve().parent

logging.basicConfig(
    level=getattr(logging, Config.LOG_LEVEL, logging.INFO),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(APP_NAME)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def create_app() -> Flask:
    app = Flask(
        __name__,
        template_folder=str(BASE_DIR / "templates"),
        static_folder=str(BASE_DIR / "static"),
    )

    app.config.update(
        SECRET_KEY=Config.SECRET_KEY,
        JSON_SORT_KEYS=False,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=Config.SESSION_COOKIE_SECURE,
        MAX_CONTENT_LENGTH=2 * 1024 * 1024,
    )

    @app.after_request
    def set_security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Cache-Control"] = "no-store"
        return response

    @app.get("/health")
    def health():
        return jsonify(
            {
                "success": True,
                "app": APP_NAME,
                "version": APP_VERSION,
                "status": "healthy",
                "environment": Config.APP_ENV,
                "timestamp": utc_now_iso(),
            }
        )

    @app.get("/api/system/config")
    def system_config():
        return jsonify(
            {
                "success": True,
                "app": APP_NAME,
                "version": APP_VERSION,
                "market": {
                    "provider": "FYERS",
                    "exchange": "NSE",
                    "timezone": Config.MARKET_TIMEZONE,
                    "index_refresh_seconds": Config.INDEX_REFRESH_SECONDS,
                    "live_price_refresh_seconds": Config.LIVE_PRICE_REFRESH_SECONDS,
                },
                "scanner": {
                    "top_sector_count": Config.TOP_SECTOR_COUNT,
                    "top_stocks_per_sector": Config.TOP_STOCKS_PER_SECTOR,
                    "universe_size": Config.STOCK_UNIVERSE_SIZE,
                    "modes": ["intraday", "btst", "swing"],
                },
                "signal_policy": {
                    "fake_data_allowed": False,
                    "strong_buy_requires_all_mandatory_rules": True,
                },
                "timestamp": utc_now_iso(),
            }
        )

    @app.get("/")
    def root():
        dashboard_template = BASE_DIR / "templates" / "dashboard.html"
        if dashboard_template.exists():
            return render_template(
                "dashboard.html",
                app_name=APP_NAME,
                app_version=APP_VERSION,
            )

        return jsonify(
            {
                "success": True,
                "app": APP_NAME,
                "version": APP_VERSION,
                "message": "Eagle Smart Scanner foundation is running.",
                "health": "/health",
                "timestamp": utc_now_iso(),
            }
        )

    @app.errorhandler(404)
    def not_found(_error):
        return (
            jsonify(
                {
                    "success": False,
                    "error": "not_found",
                    "message": "Requested endpoint does not exist.",
                    "path": request.path,
                    "timestamp": utc_now_iso(),
                }
            ),
            404,
        )

    @app.errorhandler(405)
    def method_not_allowed(_error):
        return (
            jsonify(
                {
                    "success": False,
                    "error": "method_not_allowed",
                    "message": "HTTP method is not allowed for this endpoint.",
                    "path": request.path,
                    "timestamp": utc_now_iso(),
                }
            ),
            405,
        )

    @app.errorhandler(Exception)
    def unexpected_error(exc: Exception):
        logger.exception("Unhandled application error")
        return (
            jsonify(
                {
                    "success": False,
                    "error": "internal_server_error",
                    "message": str(exc) if Config.DEBUG_ERRORS else "Internal server error.",
                    "timestamp": utc_now_iso(),
                }
            ),
            500,
        )

    return app


app = create_app()


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=int(os.getenv("PORT", "10000")),
        debug=Config.FLASK_DEBUG,
    )
