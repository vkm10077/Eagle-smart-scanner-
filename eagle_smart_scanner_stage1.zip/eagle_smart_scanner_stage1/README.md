# Eagle Smart Scanner — Stage 1

Clean production foundation for the rebuilt Eagle Smart Scanner.

## Test endpoints
- `/health`
- `/api/system/config`
- `/`

Expected `/health`: `"status": "healthy"`.

No fake/fallback market data is permitted.
