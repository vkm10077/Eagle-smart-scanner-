from __future__ import annotations

import os


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


class Config:
    APP_ENV = os.getenv("APP_ENV", "production").strip().lower()
    SECRET_KEY = os.getenv("SECRET_KEY", "change-this-in-render")
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").strip().upper()
    FLASK_DEBUG = _env_bool("FLASK_DEBUG", False)
    DEBUG_ERRORS = _env_bool("DEBUG_ERRORS", False)
    SESSION_COOKIE_SECURE = _env_bool(
        "SESSION_COOKIE_SECURE",
        APP_ENV == "production",
    )

    MARKET_TIMEZONE = "Asia/Kolkata"
    MARKET_PROVIDER = "FYERS"
    EXCHANGE = "NSE"

    FYERS_CLIENT_ID = os.getenv("FYERS_CLIENT_ID", "").strip()
    FYERS_SECRET_KEY = os.getenv("FYERS_SECRET_KEY", "").strip()
    FYERS_REDIRECT_URI = os.getenv("FYERS_REDIRECT_URI", "").strip()

    TOP_SECTOR_COUNT = 20
    TOP_STOCKS_PER_SECTOR = 10
    STOCK_UNIVERSE_SIZE = TOP_SECTOR_COUNT * TOP_STOCKS_PER_SECTOR

    INDEX_REFRESH_SECONDS = 10
    LIVE_PRICE_REFRESH_SECONDS = 5
    INTRADAY_TECH_REFRESH_SECONDS = 60
    BTST_TECH_REFRESH_SECONDS = 180
    SWING_TECH_REFRESH_SECONDS = 300
    SECTOR_REFRESH_SECONDS = 900

    EMA_FAST = 20
    EMA_MID = 50
    EMA_SLOW = 200

    RSI_PERIOD = 14
    MACD_FAST = 12
    MACD_SLOW = 26
    MACD_SIGNAL = 9
    ADX_PERIOD = 14
    ATR_PERIOD = 14
    VOLUME_AVG_PERIOD = 20

    SUPERTREND_PERIOD = 10
    SUPERTREND_MULTIPLIER = 3.0

    MODE_TIMEFRAMES = {
        "intraday": {
            "primary": "5",
            "confirmation": "15",
            "higher": "D",
            "history": 300,
        },
        "btst": {
            "primary": "15",
            "confirmation": "60",
            "higher": "D",
            "history": 300,
        },
        "swing": {
            "primary": "D",
            "confirmation": "W",
            "higher": "W",
            "history": 320,
        },
    }

    MIN_RISK_REWARD = 2.0

    MAX_STOP_LOSS_PERCENT = {
        "intraday": 2.5,
        "btst": 4.0,
        "swing": 8.0,
    }

    ENTRY_BUFFER_PERCENT = {
        "intraday": 0.05,
        "btst": 0.08,
        "swing": 0.10,
    }

    ATR_STOP_MULTIPLIER = {
        "intraday": 1.2,
        "btst": 1.3,
        "swing": 1.5,
    }

    ATR_TARGET_MULTIPLIER = {
        "intraday": 2.4,
        "btst": 2.6,
        "swing": 3.0,
    }

    BUY_MIN_SCORE = 70
    STRONG_BUY_MIN_SCORE = 80
    STRONG_BUY_REQUIRES_ALL_MANDATORY_RULES = True
    ALLOW_FAKE_DATA = False

    SIGNAL_COLUMNS = (
        "stock",
        "sector",
        "current_price",
        "technical_score",
        "entry_price",
        "stop_loss",
        "target",
        "timeframe",
        "expected_move",
        "signal",
    )
